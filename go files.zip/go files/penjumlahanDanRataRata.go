package main
import "fmt"

const NMAX int = 10
type tabInt [NMAX]int

func main(){
	var data tabInt
	var nData int
	baca(&data, &nData)
	cetak(data, nData)
	fmt.Printf("%d ",jumlah(data, nData))
	fmt.Printf("%.1f\n",rataRata(data, nData))
}

func baca(A *tabInt, n *int){
	var cek int
	for i := 0; i < NMAX; i++{
		fmt.Scan(&cek)
		if cek == 0 {break}
		if cek < 0 {cek = cek * -1}
		A[i] = cek
		*n++
	}
}

func cetak(A tabInt, n int){
	for i:= 0; i<n; i++{
		fmt.Printf("%d ", A[i])
	}
	fmt.Println("")
}

func jumlah(A tabInt, n int)int{
	var temp int = 0
	for i := 0; i<n; i++{
		temp += A[i]
	}
	return temp
}

func rataRata(A tabInt, n int)float64{
	var temp float64 = 0
	for i := 0; i<n; i++{
		temp += float64(A[i])
	}
	return temp/float64(n)
}

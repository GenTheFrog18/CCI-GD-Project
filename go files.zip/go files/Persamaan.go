package main
import "fmt"

func main(){
	var x, y int
	fmt.Scan(&x, &y)
	fmt.Println(persamaan(x, y))
}

func persamaan(x, y int) int{
	if y == 0 {return x}
	return persamaan(y, x % y)
}

package main
import "fmt"

func bacaData(A *tabInt){
	if A.n < NMAX{
		fmt.Scan(&A.info[A.n])
		A.n++
	}
}

func cetakData(A tabInt){
	for i := 0; i<NMAX ; i++{
		fmt.Printf("%d ", A.info[i])
	}
	fmt.Println("")
}

const NMAX int = 5
type tabInt struct{
	info [NMAX]int
	n int
}

func main(){
	var data tabInt
	for i := 0; i<6; i++{
		bacaData(&data)
	}
	cetakData(data)
}

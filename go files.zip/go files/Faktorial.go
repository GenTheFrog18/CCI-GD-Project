package main
import "fmt"

func main(){
	var input int
	fmt.Scan(&input)
	fmt.Println(faktorial(input))
}

func faktorial(in int) int{
	if in == 0 || in == 1{return 1}
	return in * faktorial(in-1)
}

package main
import "fmt"

func main(){
	var n int
	fmt.Scan(&n)
	printNumRecursive(n)
	fmt.Println("")
}

func printNumRecursive(n int){
	if n == 0 {return}
	printNumRecursive(n-1)
	fmt.Print(n, " ")
}

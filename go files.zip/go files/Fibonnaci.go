package main
import "fmt"

func main(){
	var input int
	fmt.Scan(&input)
	fmt.Println(fib(input))
}

func fib(in int)int{
	if in <= 2 {return 1}
	return fib(in-1) + fib(in-2)
}

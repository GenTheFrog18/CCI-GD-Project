package main
import "fmt"

const NMAX int = 100
type applicant struct{
	id, name string
	testGrade float64
	testDuration int
}
type applicants [NMAX]applicant

func main(){
	var A applicants
	var n int
	input(&A, &n)	
	fmt.Printf("\nData Awal:\n")
	cetak(A, n)
	sort(&A, n)
	fmt.Printf("\nData setelah disortir:\n")
	cetak(A, n)
}

func input(A *applicants, n *int){
	var tmp string
	for i := 0; i < NMAX; i++{
		fmt.Scan(&tmp)
		if tmp != "END"{
			A[i].id = tmp
			fmt.Scan(&A[i].name, &A[i].testGrade, &A[i].testDuration)
			*n++ 
		} else {break}
	}
}

func sort(A *applicants, n int){
	for i := 0; i < n; i++{
		idx := i
		for j := i + 1; j < n; j++{
			if A[j].testGrade > A[idx].testGrade{
				idx = j
			} else if A[j].testGrade == A[idx].testGrade{
				if A[j].testDuration < A[idx].testDuration{idx = j}
			}
		}
		tmp := A[i]
		A[i] = A[idx]
		A[idx] = tmp
	}
}

func cetak(A applicants, n int){
	for i := 0; i<n; i++{
		fmt.Printf("%s %s %.1f %d\n",A[i].id, A[i].name, A[i].testGrade, A[i].testDuration)
	}
}

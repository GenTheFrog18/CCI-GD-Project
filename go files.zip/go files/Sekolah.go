package main
import "fmt"

const NMAX int = 1001
type tabMurid [NMAX]string

func main(){
	var n int
	var A tabMurid
	var nama string
	fmt.Scan(&n)
	baca(&A, n)
	fmt.Scan(&nama)
	find(A, n, nama)
}

func baca(A *tabMurid, n int){
	for i := 0; i < n; i++{
		fmt.Scan(&A[i])
	}
}

func find(A tabMurid, n int, nama string){
	var mid, l, r, c int
	c = -1
	l = 0
	r = n-1
	for i := 0; i < n; i++{
		mid = (r + l)/2
		if A[mid] == nama{
			c = mid + 1
		} else if A[mid] < nama{
			l = mid + 1
		} else if A[mid] > nama{
			r = mid - 1
		}
	}
	if c == -1 {
		fmt.Println("Murid tidak terdaftar")
	} else {
		fmt.Println("Murid terdaftar dan berada di urutan absen ke-",c)
	}
}


package main
import "fmt"

const NMAX int = 9999
type arrString [NMAX]string

func main(){
	var A arrString
	var n int
	fmt.Scan(&n)
	bacaData(&A, n)
	selectionSortAscend(&A, n)
	fmt.Printf("\nData setelah diurutkan secara Ascending:\n")
	cetakData(A, n)
	selectionSortDescend(&A, n)
	fmt.Println("Data setelah diurutkan secara Descending:")
	cetakData(A, n)
}

func bacaData(A *arrString, n int){
	for i := 0; i<n; i++{
		fmt.Scan(&A[i])
	}
}

func cetakData(A arrString, n int){
	for i := 0; i<n; i++{
		fmt.Printf("%s, ", A[i])
	}
	fmt.Println()
}

func selectionSortAscend(A *arrString, n int){
	for i := 0; i<n; i++{
		idx := i
		for j := i+1; j<n; j++{
			if A[j] < A[idx]{idx = j}
		}
		tmp := A[i]
		A[i] = A[idx]
		A[idx] = tmp
	}
}

func selectionSortDescend(A *arrString, n int){
	for i := 0; i<n; i++{
		idx := i
		for j := i+1; j<n; j++{
			if A[j] >  A[idx]{idx = j}
		}
		tmp := A[i]
		A[i] = A[idx]
		A[idx] = tmp
	}
}

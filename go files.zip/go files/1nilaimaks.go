package main
import "fmt"

func main(){
	const NMAX int = 10
	var A [NMAX]string
	var i, n, max int
	fmt.Scan(&n)
	if n > NMAX{
		n = NMAX
	}
	for i = 0; i<n; i++{
		fmt.Scan(&A[i])
	}
	max = 0
	for i = 1; i < n; i++{
		if A[i] > A[max]{max = i}
	}
	fmt.Printf("%s %d\n", A[max], max)
}

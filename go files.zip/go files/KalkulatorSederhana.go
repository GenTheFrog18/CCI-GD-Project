package main
import "fmt"
func menu(){
fmt.Println(`-----------------------
	M E N U
-----------------------
1. Hitung Penjumlahan
2. Hitung Perkalian
3. Hitung Pembagian
4. Exit
-----------------------`)}
func hitungJumlah(){
	var a, b int
	fmt.Print("Masukkan dua bilangan yang akan dijumlahkan: ")
	fmt.Scan(&a, &b)
	fmt.Printf("Hasil penjumlahan: %d\n\n", a + b)
}
func hitungKali(){
	var a, b int
	fmt.Print("Masukkan dua bilangan yang akan dikalikan: ")
	fmt.Scan(&a, &b)
	fmt.Printf("Hasil perkalian: %d\n\n", a * b)
}
func hitungBagi(){
	var a, b float64
	fmt.Print("Masukkan dua bilangan yang akan dibagikan: ")
	fmt.Scan(&a, &b)
	fmt.Printf("Hasil pembagian: %.1f\n\n", a / b)
}
func main(){
	var n int
	for{
		menu()
		fmt.Print("Pilih (1/2/3/4)? ")
		fmt.Scan(&n)
		if n == 4 {break}
		if n == 1 {hitungJumlah()}
		if n == 2 {hitungKali()}
		if n == 3 {hitungBagi()}
	}

}

package main
import "fmt"

func main(){
	const NMAX int = 10
	var A [NMAX]string
	var i, n, min int
	fmt.Scan(&n)
	if n > NMAX{
		n = NMAX
	}
	for i = 0; i<n; i++{
		fmt.Scan(&A[i])
	}
	min = 0
	for i = 1; i < n; i++{
		if A[i] < A[min]{
			min = i
		}
	}
	fmt.Printf("%s %d\n", A[min], min)
}

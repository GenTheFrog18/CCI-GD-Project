package main
import "fmt"

const NMAX int = 50
type Barang struct{
	namaBarang string
	harga, stok int
}
type tabBarang [NMAX]Barang

func main(){
	var n int
	var data tabBarang
	fmt.Scan(&n)
	inputBarang(&data, n)
	fmt.Println()
	tampilBarang(data, n)
}

func inputBarang(data *tabBarang, n int){
	for i := 0; i < n; i++{
		fmt.Scan(&(*data)[i].namaBarang)
		fmt.Scan(&(*data)[i].harga)
		fmt.Scan(&(*data)[i].stok)
	}
}

func tampilBarang(data tabBarang, n int){
	var c bool = true
	for i := 0; i < n; i++{
		if data[i].stok < 5 {
			fmt.Printf("%s %d %d\n", data[i].namaBarang, data[i].harga, data[i].stok)
			c = false
		}
	}
	if c {fmt.Println("Tidak ada barang dengan stok kurang dari 5")}
	
}

package main
import "fmt"

const NMAX int = 20
type tabInt [NMAX]int

func baca(A *tabInt, n *int){
	var tmp int
	for i := 0; i < NMAX; i++{
		fmt.Scan(&tmp)
		if tmp > 0{
			A[i] = tmp
			*n = *n + 1
		} else {break}
	}
}

func maksimum(A tabInt, n int) int{
	var m int = 0
	for i := 0; i < n; i++{
		if A[i] > A[m]{m = i}
	}
	return A[m]
}

func minimum(A tabInt, n int) int{
	var m int = 0
	for i := 0; i < n; i++{
		if A[i] < A[m]{m = i}
	}
	return A[m]
}

func cetakElemen(A tabInt, n int){
	fmt.Print("Elemen array: ")
	for i := 0; i<n; i++{
		fmt.Printf("%d ", A[i])
	}
	fmt.Println()
}

func cetakInfo(A tabInt, n int){
	fmt.Printf("Nilai maksimum: %d\n", maksimum(A, n))
	fmt.Printf("Nilai minimum: %d\n", minimum(A, n))
	fmt.Printf("Banyak elemen: %d\n", n)
}

func main(){
	var array tabInt
	var n int
	baca(&array, &n)
	cetakElemen(array, n)
	cetakInfo(array, n)
}

package main
import "fmt"

const NMAX int = 69
type penduduk struct{
	nama string
	tahun int
	kota string
}
type tabPenduduk [NMAX]penduduk

func main(){
	var A tabPenduduk
	var n, taun int
	fmt.Scan(&n)
	baca(&A, n)
	fmt.Scan(&taun)
	find(A, n, taun)
}

func baca(A *tabPenduduk, n int){
	for i := 0; i < n; i++{
		fmt.Scan(&A[i].nama, &A[i].tahun, &A[i].kota)
	}
}

func find(A tabPenduduk, n int, taun int){
	var m, l, r, c int
	c = -1
	l = 0
	r = n-1
	for i := 0; i < n; i++{
		m = (l+r)/2
		if A[m].tahun == taun{
			c = m
		} else if A[m].tahun < taun{
			l = m + 1
		} else if A[m].tahun > taun{
			r = m - 1
		}
	}
	if c == -1 {
		fmt.Println("Data Tidak Ditemukan")
	} else {
		fmt.Printf("%s\n%d\n%s\nditemukan di indeks ke-%d\n", A[c].nama, A[c].tahun, A[c].kota, c)
	}
}



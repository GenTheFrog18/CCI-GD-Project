package main
import "fmt"
func hitungMenang(g, k int, jm *int){
	if (g>k){*jm++}
}
func hitungDraw(g, k int, jd *int){
	if (g==k){*jd++}
}
func hitungKalah(g, k int, jk *int){
	if (g<k){*jk++}
}
func hitungJumGolKegolanSelisih(g, k int, jg, jkg, jsg *int){
	*jg += g
	*jkg += k
	*jsg = *jg - *jkg
}
func hitungJumPoint(jm, jd int, jp *int){
	*jp = (jm * 3) + jd
}
func main(){
	var g, k, n, jm, jd, jk, jg, jkg, jp, jsg int
	fmt.Scan(&n)
	for i := 1; i <= n; i++{
		fmt.Scanln(&g, &k)
		hitungMenang(g,k,&jm)
		hitungDraw(g,k,&jd)
		hitungKalah(g,k,&jk)
		hitungJumGolKegolanSelisih(g,k,&jg,&jkg,&jsg)
		hitungJumPoint(jm,jd,&jp)
	}
	fmt.Printf("%d %d %d %d %d %d %d %d\n", n, jm, jd, jk, jg, jkg, jsg, jp)
}


package main
import "fmt"

func main() {
	var number int
	fmt.Print("num:")
	fmt.Scanln(&number)
	iterasi := number
	for i:=0; i < iterasi; i++ {
		fmt.Print(number)
		number = number - 1
		if number > 0 {
			fmt.Print("+")
		}
	}
	fmt.Println("")
}

package main
import "fmt"
func hitungLuasKelilingLingkaran(r float64, l, k *float64){
	const pi = 3.14
	*l = pi * r * r
	*k = 2 * pi * r
}
func hitungLuasKelilingPersegi(s float64, l, k *float64){
	*l = s * s
	*k = 4 * s
}
func hitungTotal(lL, lP, kL, kP float64, toLuas, totKel *float64){
	*toLuas = lL + lP
	*totKel = kL + kP
}
func main(){
	var r, s, lL, lP, kL, kP, toLuas, totKel float64
	fmt.Scanln(&r, &s)
	if (r == 0 && s == 0){return}
	fmt.Printf("\n%-7s %-7s %-7s %-7s %-7s %-7s %-7s %-7s\n", "R", "S", "LL", "LP", "KL", "KP", "TL", "TP")
	for{
		hitungLuasKelilingLingkaran(r, &lL, &kL)
		hitungLuasKelilingPersegi(s, &lP, &kP)
		hitungTotal(lL, lP, kL, kP, &toLuas, &totKel)
		fmt.Printf("%.2f %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f\n", r, s, lL, lP, kL, kP, toLuas, totKel)
		fmt.Scanln(&r, &s)
		if (r == 0 && s == 0){break}
	}
}




package main
import "fmt"
func main() {
	var array []int
	list := 1
	var target int
	fmt.Print("Cari: ")
	fmt.Scan(&target)
	fmt.Print("Dalam List: ")
	ada := false
	for list != 0 {
		fmt.Scan(&list)
		array = append(array, list)
	}
	for checker := range(len(array)){
		if target == array[checker]{
			fmt.Println(checker + 1)
			ada = true
		}
	}
	if ada == false {fmt.Println("TIDAK ADA")}
}
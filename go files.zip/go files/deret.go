package main
import "fmt"

func main(){
	var n int
	fmt.Scan(&n)
	fmt.Println(sumNumSeq(n))
}

func numSeq(n int)int{
	if n == 0 {return 1}
	return numSeq(n-1)*n
}

func sumNumSeq(n int)int{
	if n == 0 {return numSeq(1)-1}
	return numSeq(n) + sumNumSeq(n-1)
}

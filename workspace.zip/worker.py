import sys
import time
import sqlite3
import shutil
import os
import argparse
import warnings
import re
import unicodedata
from pathlib import Path
import stable_whisper

# Suppress Warnings
warnings.filterwarnings("ignore")
os.environ["TQDM_DISABLE"] = "1" 

# ================= CONFIGURATION =================
DB_PATH = Path("/workspace/transcripts.db")
LOCAL_ROOT = Path("/workspace/RunpodAsmr").resolve()
RAM_DIR = Path("/dev/shm/jit_buffer").resolve()
ARCHIVE_DIR = Path("/workspace/subtitle_archive").resolve()
MISSING_LOG = Path("/workspace/missing_files.txt")
MODEL_SIZE = "large-v3-turbo"
COMPUTE_TYPE = "float16"

def log(worker_id, msg):
    print(f"[{worker_id}] {msg}", flush=True)

def normalize_path(path_str):
    return unicodedata.normalize('NFC', str(path_str))

def find_local_file(db_path):
    """
    NUCLEAR SEARCH:
    1. Clean Path
    2. Smart RJ-Folder Search
    3. GLOBAL FILENAME SEARCH (The "Nuclear" Option)
    """
    # 1. Clean the path
    clean_rel = db_path.replace("Downloads/Audio/", "").replace("Downloads/", "").strip("/")
    input_file = LOCAL_ROOT / clean_rel
    
    # Tier 1: Exact Match
    if input_file.exists():
        return input_file, clean_rel

    # Tier 2: Smart RJ-Folder Search
    rj_match = re.search(r'RJ(\d+)', db_path)
    if rj_match:
        rj_num = int(rj_match.group(1))
        
        # Scan for RJ folder (handles RJ0123 vs RJ123)
        rj_dir = None
        candidates = [f"RJ{rj_num}", f"RJ{rj_num:06}", f"RJ{rj_num:08}"]
        
        # Fast candidate check
        for c in candidates:
            if (LOCAL_ROOT / c).exists():
                rj_dir = LOCAL_ROOT / c
                break
        
        # Slow directory scan if fast check failed
        if not rj_dir:
            for path in LOCAL_ROOT.iterdir():
                if path.is_dir() and f"RJ{rj_num}" in path.name:
                    rj_dir = path
                    break
        
        # If we found the RJ folder, look inside it
        if rj_dir:
            # Strategy A: Direct Filename Match inside RJ
            filename = Path(clean_rel).name
            target = rj_dir / filename
            if target.exists():
                return target, str(target.relative_to(LOCAL_ROOT))
                
            # Strategy B: Recursive Filename Match inside RJ
            found = list(rj_dir.rglob(filename))
            if found:
                return found[0], str(found[0].relative_to(LOCAL_ROOT))

            # Strategy C: Largest Audio File Fallback
            audio_files = []
            audio_exts = {'.opus', '.mp3', '.wav', '.m4a', '.flac', '.mp4'}
            for f in rj_dir.rglob("*"):
                if f.is_file() and f.suffix.lower() in audio_exts:
                    audio_files.append(f)
            
            if audio_files:
                largest = max(audio_files, key=lambda x: x.stat().st_size)
                return largest, str(largest.relative_to(LOCAL_ROOT))

    # Tier 3: NUCLEAR OPTION (Global Filename Search)
    # If RJ search failed, just search the WHOLE DISK for this filename.
    filename = Path(clean_rel).name
    log("SEARCH", f"Going Nuclear for: {filename}")
    try:
        found_global = list(LOCAL_ROOT.rglob(filename))
        if found_global:
            return found_global[0], str(found_global[0].relative_to(LOCAL_ROOT))
    except:
        pass

    return None, None

def mark_as_missing(worker_id, db_id, audio_path):
    try:
        with open(MISSING_LOG, "a", encoding="utf-8") as f:
            f.write(f"{audio_path}\n")
        
        conn = sqlite3.connect(DB_PATH, timeout=60.0)
        conn.execute("UPDATE audio_files SET is_transcribed = -1 WHERE id = ?", (db_id,))
        conn.commit()
        conn.close()
        log(worker_id, f"MISSING LOGGED: {audio_path[:30]}")
    except: pass

def run_worker(gpu_index, worker_id):
    RAM_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    
    log(worker_id, f"Initializing on GPU {gpu_index}...")
    try:
        model = stable_whisper.load_faster_whisper(
            MODEL_SIZE, device="cuda", device_index=gpu_index, compute_type=COMPUTE_TYPE
        )
        log(worker_id, "Model Loaded.")
    except Exception as e:
        log(worker_id, f"CRITICAL LOAD ERROR: {e}")
        return
    
    while True:
        try:
            conn = sqlite3.connect(DB_PATH, timeout=60.0)
            conn.row_factory = sqlite3.Row
            row = conn.execute("""
                SELECT id, audio_path FROM audio_files 
                WHERE (is_transcribed = 0 OR is_transcribed IS NULL) 
                AND has_subtitle = 0 ORDER BY RANDOM() LIMIT 1
            """).fetchone()
            conn.close()
        except:
            time.sleep(1); continue

        if not row:
            log(worker_id, "No more jobs found."); break

        input_file, rel_path = find_local_file(row["audio_path"])
        
        if not input_file or not input_file.exists():
            mark_as_missing(worker_id, row["id"], row["audio_path"])
            continue

        wav_name = f"{row['id']}_{worker_id}.wav"
        wav_path = RAM_DIR / wav_name
        
        try:
            log(worker_id, f"Processing: {input_file.name[:20]}...")
            if not wav_path.exists():
                os.system(f"ffmpeg -y -i \"{input_file}\" -ar 16000 -ac 1 -c:a pcm_s16le \"{wav_path}\" > /dev/null 2>&1")

            if not wav_path.exists():
                mark_as_missing(worker_id, row["id"], row["audio_path"])
                continue

            result = model.transcribe(
                str(wav_path), batch_size=48, vad=True, verbose=None, 
                regroup="mg=0.2_sp=.* /./. /。/?/? /？/!/! /！/,/, _sl=25"
            )
            
            srt_name = Path(rel_path).stem + ".srt"
            final_srt = ARCHIVE_DIR / rel_path
            final_srt.parent.mkdir(parents=True, exist_ok=True)
            result.to_srt_vtt(str(final_srt.parent / srt_name), word_level=False)
            
            shutil.copy(str(final_srt.parent / srt_name), str(input_file.parent / srt_name))

            conn = sqlite3.connect(DB_PATH, timeout=60.0)
            conn.execute("UPDATE audio_files SET is_transcribed = 1 WHERE id = ?", (row["id"],))
            conn.commit()
            conn.close()
            log(worker_id, f"DONE: {srt_name[:20]}")

        except Exception as e:
            log(worker_id, f"ERROR: {e}")
        finally:
            if wav_path.exists():
                try: os.remove(wav_path)
                except: pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", type=int, required=True)
    parser.add_argument("--name", type=str, required=True)
    args = parser.parse_args()
    run_worker(args.gpu, args.name)
import asyncio
import os
import shutil
import sqlite3
import sys
import random
from pathlib import Path
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.layout import Layout
from rich.progress import Progress, BarColumn, TextColumn
import stable_whisper

# ================= CONFIGURATION =================
DB_PATH = Path("/workspace/transcripts.db")
# The root folder where you dumped your GDrive
LOCAL_ROOT = Path("/workspace/RunpodAsmr").resolve()
RAM_DIR = Path("/dev/shm/jit_buffer").resolve()
ARCHIVE_DIR = Path("/workspace/subtitle_archive").resolve()

MODEL_SIZE = "large-v3-turbo" 
BATCH_SIZE = 48        
COMPUTE_TYPE = "float16"

PRODUCER_COUNT = 8     # 8 CPU Threads converting audio
CONSUMER_COUNT = 4     # 4 GPU Workers

# ================= STATE =================
class FactoryState:
    def __init__(self):
        self.gpu_jobs = ["Idle"] * CONSUMER_COUNT
        self.ram_queue_size = 0
        self.completed_session = 0
        self.gpu_util = "0%"
        self.vram = "0GB"
        self.db_remaining = "Checking..."
        self.last_error = "None"

state = FactoryState()

# ================= WORKERS =================
async def db_monitor():
    while True:
        try:
            conn = sqlite3.connect(DB_PATH)
            count = conn.execute("SELECT COUNT(*) FROM audio_files WHERE (is_transcribed = 0 OR is_transcribed IS NULL) AND has_subtitle = 0").fetchone()[0]
            conn.close()
            state.db_remaining = str(count)
        except: state.db_remaining = "Error"
        await asyncio.sleep(5)

async def cpu_producer(queue, worker_id):
    while True:
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            row = conn.execute("""
                SELECT id, audio_path FROM audio_files 
                WHERE (is_transcribed = 0 OR is_transcribed IS NULL) 
                AND has_subtitle = 0 ORDER BY RANDOM() LIMIT 1
            """).fetchone()
            conn.close()

            if not row:
                await asyncio.sleep(5)
                continue

            # --- PATH FIXER LOGIC ---
            # DB Path example: "Downloads/Audio/RJ123456/voice.opus"
            # We need to find where that is in LOCAL_ROOT
            
            # 1. Strip "Downloads/" prefix
            clean_rel = row["audio_path"].replace("Downloads/", "")
            
            # 2. Try direct map
            input_file = LOCAL_ROOT / clean_rel
            
            # 3. If not found, try stripping one more folder level (Common issue)
            if not input_file.exists():
                parts = Path(clean_rel).parts
                if len(parts) > 1:
                     # Try "Audio/RJ1234..." instead of "RunpodAsmr/Audio/..."
                     input_file = LOCAL_ROOT / Path(*parts[1:])

            if not input_file.exists():
                # Debugging: Mark as "Missing" so we don't loop forever
                # (Optional: Uncomment this line if you want to skip missing files forever)
                # conn.execute("UPDATE audio_files SET is_transcribed = -1 WHERE id = ?", (row["id"],))
                state.last_error = f"Missing: {clean_rel}"
                await asyncio.sleep(2)
                continue

            wav_name = f"{row['id']}_{worker_id}.wav"
            wav_path = RAM_DIR / wav_name
            
            if not wav_path.exists():
                proc = await asyncio.create_subprocess_exec(
                    "ffmpeg", "-y", "-i", str(input_file),
                    "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", str(wav_path),
                    stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
                )
                await proc.communicate()

            await queue.put({"id": row["id"], "wav": wav_path, "rel": clean_rel, "src": str(input_file)})
            state.ram_queue_size = queue.qsize()

        except Exception as e:
            state.last_error = str(e)
            await asyncio.sleep(1)

async def gpu_consumer(queue, worker_id):
    target_gpu_index = 0 if worker_id < 2 else 1
    
    print(f"Loading Model for Worker {worker_id} on GPU {target_gpu_index}...")
    try:
        model = stable_whisper.load_faster_whisper(
            MODEL_SIZE, device="cuda", device_index=target_gpu_index, compute_type=COMPUTE_TYPE
        )
    except: return

    while True:
        job = await queue.get()
        state.gpu_jobs[worker_id] = f"[G{target_gpu_index}] {job['rel'][:15]}"
        
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None, lambda: model.transcribe(
                    str(job['wav']), batch_size=BATCH_SIZE, vad=True, verbose=False,
                    regroup="mg=0.2_sp=.* /./. /。/?/? /？/!/! /！/,/, _sl=25"
                )
            )
            
            srt_name = Path(job['rel']).stem + ".srt"
            
            # Archive
            final_srt = ARCHIVE_DIR / job['rel']
            final_srt.parent.mkdir(parents=True, exist_ok=True)
            result.to_srt_vtt(str(final_srt.parent / srt_name), word_level=False)
            
            # Local Copy (Next to audio file)
            local_srt_copy = Path(job['src']).parent / srt_name
            shutil.copy(str(final_srt.parent / srt_name), str(local_srt_copy))

            conn = sqlite3.connect(DB_PATH)
            conn.execute("UPDATE audio_files SET is_transcribed = 1 WHERE id = ?", (job["id"],))
            conn.commit()
            conn.close()
            state.completed_session += 1

        except Exception as e:
            state.last_error = f"GPU Fail: {e}"
        finally:
            if job['wav'].exists(): os.remove(job['wav'])
            state.gpu_jobs[worker_id] = "Idle"
            state.ram_queue_size = queue.qsize()
            queue.task_done()

# ================= UI =================
def get_dashboard():
    try:
        import subprocess
        res = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used", "--format=csv,noheader,nounits"], encoding="utf-8"
        )
        lines = res.strip().split('\n')
        g0_util, g0_mem = lines[0].split(',')
        g1_util, g1_mem = lines[1].split(',')
        state.gpu_util = f"G0: {g0_util.strip()}% | G1: {g1_util.strip()}%"
        state.vram = f"G0: {int(g0_mem.strip())/1024:.1f}G | G1: {int(g1_mem.strip())/1024:.1f}G"
    except: pass

    status_str = f"[bold green]Active Workers[/bold green]\n"
    for i, job in enumerate(state.gpu_jobs):
        status_str += f"W{i}: [cyan]{job}[/cyan]\n"
    
    status_str += f"\nRAM Buffer: [bold yellow]{state.ram_queue_size}[/] files ready"
    status_str += f"\nDB Pending: [bold magenta]{state.db_remaining}[/] files"
    if state.last_error != "None":
        status_str += f"\n[bold red]Last Error:[/bold red] {state.last_error[:40]}"

    hw_panel = Panel(
        f"GPU Load: [bold red]{state.gpu_util}[/]\n"
        f"VRAM: [bold yellow]{state.vram}[/]\n"
        f"Completed: {state.completed_session}", 
        title="Dual 4090 Stats"
    )

    layout = Layout()
    layout.split_row(Layout(Panel(status_str, title="JIT Pipeline"), ratio=2), Layout(hw_panel))
    return layout

async def main():
    RAM_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    try: conn.execute("ALTER TABLE audio_files ADD COLUMN is_transcribed INTEGER DEFAULT 0")
    except: pass
    conn.close()

    queue = asyncio.Queue(maxsize=30) 
    
    tasks = [asyncio.create_task(db_monitor())]
    for i in range(PRODUCER_COUNT): tasks.append(asyncio.create_task(cpu_producer(queue, i)))
    for i in range(CONSUMER_COUNT): tasks.append(asyncio.create_task(gpu_consumer(queue, i)))
    
    with Live(get_dashboard(), refresh_per_second=4, screen=True) as live:
        while True:
            live.update(get_dashboard())
            await asyncio.sleep(0.5)

if __name__ == "__main__":
    try: asyncio.run(main())
    except KeyboardInterrupt: pass
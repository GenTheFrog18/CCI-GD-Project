#!/bin/bash

# ================= CONFIGURATION =================
# Source: Where your SRTs are currently sitting
LOCAL_SOURCE="/workspace/subtitle_archive"

# Destination: Your GDrive + the "Audio" subfolder
# This maps "subtitle_archive/RJ123" -> "RunpodAsmr/Audio/RJ123"
REMOTE_DEST="gdrive:RunpodAsmr/Audio"

# Performance Settings
TRANSFERS=32
CHECKERS=32
# =================================================

echo "Starting Rclone SRT Upload..."
echo "Source: $LOCAL_SOURCE"
echo "Target: $REMOTE_DEST"

# The Magic Command
# 1. move: Moves files (deletes from source after upload)
# 2. --include: Only touches .srt files
# 3. --delete-empty-src-dirs: Automatically cleans up the empty folders in archive
# 4. --create-empty-src-dirs: Ensures we don't accidentally wipe the root if empty
rclone move "$LOCAL_SOURCE" "$REMOTE_DEST" \
  --include "*.srt" \
  --transfers $TRANSFERS \
  --checkers $CHECKERS \
  --delete-empty-src-dirs \
  --progress \
  --verbose

echo "Upload Complete. Local archive is clean."
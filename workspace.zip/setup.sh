#!/bin/bash

# 1. System & Locale
apt-get update && apt-get install -y btop tmux ffmpeg sqlite3 locales libcudnn8
locale-gen ja_JP.UTF-8
update-locale LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# 2. Python Deps
pip install stable-ts faster-whisper rich

# 3. Optimize Database (Persistent WAL Mode)
# This makes DB writes instant by using a memory journal
sqlite3 /workspace/transcripts.db "PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;"

# 4. PRE-CACHE MODEL TO RAM
# We download the model once to /dev/shm so workers load it from RAM, not SSD.
echo "Downloading Model to RAM Cache..."
python3 -c '
from faster_whisper import download_model
model_path = download_model("large-v3-turbo", output_dir="/dev/shm/model_cache")
print(f"Model cached to {model_path}")
'

# 5. Launch Swarm
# We use the new v3 scripts

echo "===================================================="
echo "🚀 RAM-OPTIMIZED SWARM STARTED"
echo "===================================================="
echo "Model Cache: /dev/shm/model_cache (Instant Load)"
echo "DB Mode:     WAL (High Concurrency)"
echo "===================================================="
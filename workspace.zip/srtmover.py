import os
import shutil
import unicodedata
from pathlib import Path
import stable_whisper

# ================= CONFIGURATION =================
# 1. Archive (Source of SRTs)
# Structure: /workspace/subtitle_archive/RJ123/audio/file.srt
ARCHIVE_ROOT = Path("/workspace/subtitle_archive").resolve()

# 2. GDrive (Destination)
# Structure: /workspace/RunpodAsmr/Audio/RJ123/audio/file.opus
GDRIVE_ROOT = Path("/workspace/RunpodAsmr").resolve()

# 3. Settings
MODEL_SIZE = "large-v3-turbo"
COMPUTE_TYPE = "float16"
AUDIO_EXTS = {'.opus', '.mp3', '.wav', '.m4a', '.flac', '.mp4'}
# =================================================

def smart_move_transcripts():
    print("\n[PHASE 1] Moving Transcripts to GDrive...")
    moved_count = 0
    
    # We explicitly look for the "Audio" folder in GDrive
    # If your structure is RunpodAsmr/Audio/RJ..., this is the target root.
    gdrive_audio_root = GDRIVE_ROOT / "Audio"
    if not gdrive_audio_root.exists():
        # Fallback if "Audio" folder is missing, just use root
        print("   [NOTE] 'Audio' subfolder not found. Using root.")
        gdrive_audio_root = GDRIVE_ROOT

    for root, dirs, files in os.walk(ARCHIVE_ROOT):
        for name in files:
            if name.endswith(".srt"):
                source_srt = Path(root) / name
                
                # archive_rel_path is likely: RJ123456/audio/filename.srt
                archive_rel_path = source_srt.relative_to(ARCHIVE_ROOT)
                
                # Construct Destination:
                # RunpodAsmr/Audio/ + RJ123456/audio/filename.srt
                dest_file = gdrive_audio_root / archive_rel_path
                
                # Verify that the destination FOLDER actually exists before copying
                # (This ensures we aren't creating ghost folders for deleted files)
                if dest_file.parent.exists():
                    try:
                        shutil.copy2(source_srt, dest_file)
                        print(f"   -> Moved: {archive_rel_path}")
                        moved_count += 1
                    except Exception as e:
                        print(f"   [ERROR] Copy failed: {e}")
                else:
                    # If exact path fails, try a "Fuzzy Match" 
                    # (Find the RJ folder anywhere and dump it there)
                    parts = archive_rel_path.parts
                    rj_id = next((p for p in parts if "RJ" in p), None)
                    if rj_id:
                        found_folders = list(GDRIVE_ROOT.rglob(rj_id))
                        if found_folders:
                            # Use the first matching RJ folder found
                            fuzzy_dest = found_folders[0] / name
                            try:
                                shutil.copy2(source_srt, fuzzy_dest)
                                print(f"   -> [Fuzzy Match] Moved to: {fuzzy_dest.parent.name}/{name}")
                                moved_count += 1
                            except: pass

    print(f"   >> Phase 1 Complete. Moved {moved_count} transcripts.")

def delete_empty_folders():
    print("\n[PHASE 2] Deleting Empty Folders...")
    deleted_count = 0
    # Walk bottom-up
    for root, dirs, files in os.walk(GDRIVE_ROOT, topdown=False):
        for name in dirs:
            dir_path = Path(root) / name
            try:
                dir_path.rmdir() 
                print(f"   -> Deleted: {name}")
                deleted_count += 1
            except OSError:
                pass
    print(f"   >> Phase 2 Complete. Deleted {deleted_count} empty folders.")

def transcribe_leftovers():
    print("\n[PHASE 3] Transcribing Remaining Files...")
    todo_list = []
    
    for root, dirs, files in os.walk(GDRIVE_ROOT):
        for name in files:
            file_path = Path(root) / name
            if file_path.suffix.lower() in AUDIO_EXTS:
                srt_path = file_path.with_suffix(".srt")
                if not srt_path.exists():
                    todo_list.append(file_path)
    
    if not todo_list:
        print("   >> No remaining files found! You are 100% done.")
        return

    print(f"   >> Found {len(todo_list)} files to process.")
    
    try:
        model = stable_whisper.load_faster_whisper(MODEL_SIZE, device="cuda", compute_type=COMPUTE_TYPE)
    except Exception as e:
        print(f"   [ERROR] Could not load model: {e}")
        return

    for i, audio_file in enumerate(todo_list):
        print(f"   [{i+1}/{len(todo_list)}] Processing: {audio_file.name}")
        try:
            result = model.transcribe(
                str(audio_file), batch_size=16, vad=True, verbose=None,
                regroup="mg=0.2_sp=.* /./. /。/?/? /？/!/! /！/,/, _sl=25"
            )
            srt_path = audio_file.with_suffix(".srt")
            result.to_srt_vtt(str(srt_path), word_level=False)
            print(f"      [OK] Saved SRT.")
        except Exception as e:
            print(f"      [FAILED] {e}")

    print("\n   >> Phase 3 Complete.")

if __name__ == "__main__":
    smart_move_transcripts()
    delete_empty_folders()
    transcribe_leftovers()

import subprocess
import shutil
import sys
import os
from pathlib import Path

# ================= CONFIGURATION =================
# Source (Your GDrive Remote Name)
SOURCE_REMOTE = "gdrive:RunpodAsmr/Audio"

# Destination (Your Local Workspace)
# We map the GDrive root to this folder
DEST_PATH = "/workspace/RunpodAsmr"

# ================= TUNING FOR 4 vCPU / 8GB RAM =================
# Transfers: Number of files to download in parallel.
# 24 is a sweet spot for 4 cores. Too high = CPU choke.
TRANSFERS = "24"

# Checkers: How many file metadata checks to run in parallel.
CHECKERS = "48"

# Chunk Size: The size of chunks to request from Google.
# Larger = faster for big files, but uses more RAM.
# 64MB * 24 transfers = ~1.5GB RAM usage (Safe for 8GB total).
CHUNK_SIZE = "64M"

# Buffer Size: Memory buffer per file.
# 32MB * 24 transfers = ~768MB RAM usage.
BUFFER_SIZE = "32M"

def install_rclone_if_missing():
    if not shutil.which("rclone"):
        print("⚡ Rclone not found. Installing...")
        subprocess.run("curl https://rclone.org/install.sh | bash", shell=True, check=True)
        print("✅ Rclone installed.")

def run_fast_transfer():
    install_rclone_if_missing()

    print(f"\n🚀 STARTING HIGH-SPEED TRANSFER")
    print(f"   Source: {SOURCE_REMOTE}")
    print(f"   Dest:   {DEST_PATH}")
    print(f"   Tuning: {TRANSFERS} Threads | {CHUNK_SIZE} Chunks\n")

    # Create destination if it doesn't exist
    Path(DEST_PATH).mkdir(parents=True, exist_ok=True)

    # The Command
    cmd = [
        "rclone", "copy", SOURCE_REMOTE, DEST_PATH,
        "-v",                          # Verbose (show file names)
        "-P",                          # Show Progress Bar
        "--transfers", TRANSFERS,      # Parallel downloads
        "--checkers", CHECKERS,        # Fast scanning
        "--drive-chunk-size", CHUNK_SIZE, # Optimization for GDrive
        "--buffer-size", BUFFER_SIZE,  # Memory buffer
        "--drive-use-trash=false",     # Skip trash logic for speed
        "--stats", "1s",               # Update UI every second
        "--stats-one-line"             # Keep UI clean
    ]

    try:
        # We use subprocess.call to let rclone take over the terminal UI
        subprocess.run(cmd, check=True)
        print("\n✅ TRANSFER COMPLETE.")
    except subprocess.CalledProcessError:
        print("\n❌ Transfer interrupted or failed.")
    except KeyboardInterrupt:
        print("\n🛑 Transfer stopped by user.")

if __name__ == "__main__":
    run_fast_transfer()
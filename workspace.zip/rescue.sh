#!/bin/bash

# ================= CONFIGURATION =================
LOCAL_SOURCE="/workspace/subtitle_archive/Audio"
# The Target: We upload INTO this folder. 
# Result: RunpodAsmr/Audio/RJxxx...
REMOTE_DEST="gdrive:RunpodAsmr/Audio"

# PERFORMANCE TUNING (For High-Spec VPS)
# SRT files are tiny, so we maximize the count (transfers/checkers) 
# rather than bandwidth.
TRANSFERS=64      # Run 64 file moves at once
CHECKERS=128      # Scan 128 files at once
TPS_LIMIT=0       # No transaction limit (Google limit is usually ~10/sec per client)
# =================================================

echo "--- STARTING MONSTER UPLOAD ---"
echo "Source: $LOCAL_SOURCE"
echo "Target: $REMOTE_DEST"
echo "Threads: $TRANSFERS parallel transfers"

rclone move "$LOCAL_SOURCE" "$REMOTE_DEST" \
  --transfers $TRANSFERS \
  --checkers $CHECKERS \
  --tpslimit $TPS_LIMIT \
  --fast-list \
  --delete-empty-src-dirs \
  --progress \
  --stats 1s \
  --verbose

echo "--- UPLOAD COMPLETE ---"
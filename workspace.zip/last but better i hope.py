import os
import shutil
import subprocess
import multiprocessing as mp
from pathlib import Path
import stable_whisper

# ================= CONFIGURATION =================
LOCAL_ROOT = Path("/workspace/RunpodAsmr").resolve()
REMOTE_ROOT = "gdrive:RunpodAsmr/Audio"
RAM_BASE = Path("/dev/shm/parallel_cleanup")

# Whisper Settings
MODEL_SIZE = "large-v3-turbo"
COMPUTE_TYPE = "float16"
AUDIO_EXTS = {'.opus', '.mp3', '.wav', '.m4a', '.flac', '.mp4'}

# Set this to the number of GPUs you want to use (e.g., 2)
NUM_GPUS = 2 
# =================================================

def gpu_worker(gpu_id, file_subset):
    """Worker process for a single GPU."""
    worker_name = f"GPU_{gpu_id}"
    print(f"[{worker_name}] Starting with {len(file_subset)} files.")
    
    # Create unique RAM buffer for this worker
    worker_ram = RAM_BASE / worker_name
    worker_ram.mkdir(parents=True, exist_ok=True)
    
    # Initialize Model on specific GPU
    try:
        model = stable_whisper.load_faster_whisper(
            MODEL_SIZE, 
            device="cuda", 
            device_index=gpu_id, 
            compute_type=COMPUTE_TYPE
        )
    except Exception as e:
        print(f"[{worker_name}] CRITICAL LOAD ERROR: {e}")
        return

    for i, audio_path in enumerate(file_subset):
        wav_path = worker_ram / f"temp_{i}.wav"
        try:
            print(f"[{worker_name}] [{i+1}/{len(file_subset)}] Processing: {audio_path.name}")
            
            # A. Convert to WAV in RAM (Safe for Japanese chars/Special symbols)
            os.system(f'ffmpeg -y -i "{audio_path}" -ar 16000 -ac 1 -c:a pcm_s16le "{wav_path}" -hide_banner -loglevel error')
            
            if not wav_path.exists():
                continue

            # B. Transcribe using the worker's specific regrouping config
            result = model.transcribe(
                str(wav_path),
                batch_size=48,
                vad=True,
                verbose=None,
                regroup="mg=0.2_sp=.* /./. /。/?/? /？/!/! /！/,/, _sl=25"
            )
            
            # C. Save SRT Locally
            srt_path = audio_path.with_suffix(".srt")
            result.to_srt_vtt(str(srt_path), word_level=False)
            
            # D. Rclone Move to GDrive
            rel_dir = audio_path.parent.relative_to(LOCAL_ROOT)
            remote_dest = f"{REMOTE_ROOT}/{rel_dir}"
            
            # Move the SRT (removes local copy after successful upload)
            rclone_cmd = ["rclone", "move", str(srt_path), remote_dest, "--transfers", "10"]
            proc = subprocess.run(rclone_cmd, capture_output=True, text=True)
            
            if proc.returncode == 0:
                # E. Cleanup Local Audio
                os.remove(audio_path)
                print(f"[{worker_name}] ✅ Success & Cleaned: {audio_path.name}")
            else:
                print(f"[{worker_name}] ⚠️ Upload failed, audio preserved.")

        except Exception as e:
            print(f"[{worker_name}] ❌ Error: {e}")
        finally:
            if wav_path.exists():
                os.remove(wav_path)

    # Cleanup worker RAM folder
    if worker_ram.exists():
        shutil.rmtree(worker_ram)

def main():
    print("--- PARALLEL GPU CLEANUP INITIALIZED ---")
    
    # 1. Gather all files missing SRTs
    all_files = []
    for root, dirs, files in os.walk(LOCAL_ROOT):
        for name in files:
            p = Path(root) / name
            if p.suffix.lower() in AUDIO_EXTS:
                if not p.with_suffix(".srt").exists():
                    all_files.append(p)

    if not all_files:
        print("🎉 No untranscribed files found.")
        return

    print(f"Total files found: {len(all_files)}")
    print(f"Distributing across {NUM_GPUS} GPUs...")

    # 2. Chunk files for each GPU
    chunks = [all_files[i::NUM_GPUS] for i in range(NUM_GPUS)]
    
    # 3. Spawn Processes
    processes = []
    for gpu_id in range(NUM_GPUS):
        p = mp.Process(target=gpu_worker, args=(gpu_id, chunks[gpu_id]))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

    # Final logic cleanup
    if RAM_BASE.exists():
        shutil.rmtree(RAM_BASE)
    print("\n--- ALL GPU WORKERS FINISHED ---")

if __name__ == "__main__":
    main()
import subprocess
import time
import sys
import signal
import os
import sqlite3
import threading
import torch
from collections import deque
from pathlib import Path
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.layout import Layout
from rich.table import Table

DB_PATH = Path("/workspace/transcripts.db")

# MAX PERFORMANCE SETTING
# Since we decoupled the CPU, we can safely run 4 workers per GPU.
# The buffering will prevent the CPU bottlenecks we saw before.
WORKERS_PER_GPU = 6

log_buffer = deque(maxlen=20)
worker_states = {} 
processes = []
console = Console()

def read_stream(process, name):
    for line in iter(process.stdout.readline, b''):
        msg = line.decode().strip()
        if msg:
            log_buffer.append(f"[dim]{time.strftime('%H:%M:%S')}[/dim] {msg}")
            if "Transcribing" in msg: worker_states[name] = "[bold green]Transcribing[/]"
            elif "Decoding" in msg: worker_states[name] = "[bold blue]Decoding[/]"
            elif "DONE" in msg: worker_states[name] = "[bold cyan]Finished[/]"
            elif "Model Ready" in msg: worker_states[name] = "[green]Ready[/]"
            elif "ERROR" in msg: worker_states[name] = "[bold red]ERROR[/]"

def start_swarm():
    try:
        gpu_count = torch.cuda.device_count()
        console.print(f"[bold green]Detected {gpu_count} GPUs![/bold green]")
    except: sys.exit(1)

    for gpu_idx in range(gpu_count):
        for i in range(WORKERS_PER_GPU):
            name = f"W{gpu_idx}-{i}"
            worker_states[name] = "Booting..."
            p = subprocess.Popen(
                [sys.executable, "worker.py", "--gpu", str(gpu_idx), "--name", name],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT 
            )
            processes.append(p)
            t = threading.Thread(target=read_stream, args=(p, name), daemon=True)
            t.start()

def get_dashboard():
    try:
        conn = sqlite3.connect(DB_PATH)
        pending = conn.execute("SELECT COUNT(*) FROM audio_files WHERE is_transcribed = 0 OR is_transcribed IS NULL").fetchone()[0]
        completed = conn.execute("SELECT COUNT(*) FROM audio_files WHERE is_transcribed = 1").fetchone()[0]
        conn.close()
    except: pending, completed = 0, 0

    gpu_stats = ""
    try:
        res = subprocess.check_output(["nvidia-smi", "--query-gpu=index,utilization.gpu,memory.used", "--format=csv,noheader,nounits"], encoding="utf-8")
        for line in res.strip().split('\n'):
            i, u, m = line.split(',')
            gpu_stats += f"GPU {i}: [yellow]{u.strip()}%[/] | [cyan]{int(m.strip())//1024}GB[/]\n"
    except: pass

    w_table = Table(show_header=True, header_style="bold magenta", expand=True)
    w_table.add_column("Worker")
    w_table.add_column("State")
    for name, state in sorted(worker_states.items(), key=lambda x: (int(x[0].split('-')[0][1:]), int(x[0].split('-')[1]))):
        w_table.add_row(name, state)

    layout = Layout()
    layout.split_column(Layout(name="top", ratio=2), Layout(name="bottom", ratio=1))
    layout["top"].split_row(Layout(Panel(w_table, title="Swarm Status"), ratio=1), Layout(Panel(f"Pending: {pending}\nDone: {completed}\n\n{gpu_stats}", title="Telemetry"), ratio=1))
    layout["bottom"].update(Panel("\n".join(list(log_buffer)), title="Event Log", style="white on black"))
    return layout

if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda x, y: [p.terminate() for p in processes] or sys.exit(0))
    start_swarm()
    with Live(get_dashboard(), refresh_per_second=2, screen=True) as live:
        while True:
            live.update(get_dashboard())
            if not processes: break
            time.sleep(0.5)
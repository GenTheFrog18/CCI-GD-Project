import os
from pathlib import Path

# ================= CONFIGURATION =================
# Where your files are
TARGET_DIR = Path("/workspace/RunpodAsmr").resolve()

# Extensions to target for deletion
AUDIO_EXTS = {'.opus', '.mp3', '.wav', '.m4a', '.flac', '.mp4'}

# SAFETY SWITCH: Set to False to actually delete files
# I enabled this by default so you can see what will happen first.
DRY_RUN = True 
# =================================================

def get_size(path):
    return path.stat().st_size

def run_cleanup():
    deleted_count = 0
    reclaimed_space = 0
    skipped_count = 0

    print(f"Scanning {TARGET_DIR}...")
    print(f"Mode: {'[DRY RUN - No files will be deleted]' if DRY_RUN else '[LIVE - DELETING FILES]'}")
    print("-" * 50)

    for root, dirs, files in os.walk(TARGET_DIR):
        for name in files:
            file_path = Path(root) / name
            
            # Check if it is an audio file
            if file_path.suffix.lower() in AUDIO_EXTS:
                # Look for the matching SRT
                # Example: "audio.opus" expects "audio.srt"
                srt_path = file_path.with_suffix(".srt")
                
                if srt_path.exists():
                    # SAFE TO DELETE
                    size = get_size(file_path)
                    if DRY_RUN:
                        print(f"[WOULD DELETE] {name} ({size / 1024 / 1024:.2f} MB)")
                    else:
                        try:
                            os.remove(file_path)
                            print(f"[DELETED] {name}")
                        except Exception as e:
                            print(f"[ERROR] Could not delete {name}: {e}")
                    
                    deleted_count += 1
                    reclaimed_space += size
                else:
                    # NOT SAFE - KEEP IT
                    print(f"[SKIPPING] {name} (No .srt found!)")
                    skipped_count += 1

    print("-" * 50)
    print("CLEANUP COMPLETE")
    print(f"Audio Files Processed: {deleted_count}")
    print(f"Audio Files Skipped:   {skipped_count}")
    print(f"Space Reclaimed:       {reclaimed_space / 1024 / 1024 / 1024:.2f} GB")
    
    if DRY_RUN:
        print("\nTo actually delete these files, edit the script and set DRY_RUN = False")

if __name__ == "__main__":
    run_cleanup()

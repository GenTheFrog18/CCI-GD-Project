#!/bin/bash

# ================= CONFIGURATION =================
# The folder where the mess is located
TARGET_DIR="/workspace/subtitle_archive/Audio"

# Number of parallel threads (Safe for file operations)
THREADS=32
# =================================================

# Export the function so parallel workers can see it
fix_collision() {
    copy_folder="$1"
    
    # Calculate the intended name (Strip '_copy1')
    # Example: RJ123456_copy1 -> RJ123456
    real_folder="${copy_folder%-Copy1}"
    
    # 1. Check if the "Blocking" folder exists
    if [ -d "$real_folder" ]; then
        # Check if it's actually a directory before deleting
        echo "   [FIXING] Collision found: $(basename "$real_folder")"
        
        # DELETE the broken folder (the one with empty subfolders)
        rm -rf "$real_folder"
    fi
    
    # 2. Rename the _copy1 folder to the correct name
    if [ -d "$copy_folder" ]; then
        mv "$copy_folder" "$real_folder"
        echo "   [SUCCESS] Restored: $(basename "$real_folder")"
    fi
}
export -f fix_collision

echo "--- STARTING PARALLEL REPAIR ---"
echo "Target: $TARGET_DIR"
echo "Threads: $THREADS"

# Find all folders ending in _copy1 and feed them to the workers
# -maxdepth 1 ensures we don't accidentally look inside the folders
find "$TARGET_DIR" -maxdepth 1 -type d -name "*-Copy1" -print0 | \
xargs -0 -P "$THREADS" -I {} bash -c 'fix_collision "{}"'

echo "--- REPAIR COMPLETE ---"
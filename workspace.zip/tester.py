import asyncio
import os
import shutil
import sqlite3
import sys
import time
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.live import Live
from rich.layout import Layout
from rich.table import Table
import stable_whisper

# ================= CONFIGURATION =================
DB_PATH = Path("/workspace/transcripts.db")
# Absolute paths to prevent rclone confusion
TEMP_DIR = Path("/dev/shm/transcription_tester").resolve()
ARCHIVE_DIR = Path("/workspace/subtitle_archive").resolve()
RCLONE_REMOTE = "gdrive:RunpodAsmr"
STRIP_PREFIX = "Downloads/"

MODEL_SIZE = "large-v3-turbo" 
OUTPUT_PREFIX = "[AI] " 
BATCH_SIZE = 50       

# ================= STATE =================
state_info = {"status": "Init", "details": "Waiting..."}
console = Console()

# ================= DB HELPER =================
def ensure_db_schema():
    if not DB_PATH.exists():
        state_info["status"] = "Error"
        state_info["details"] = "DB Not Found"
        return False
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("SELECT is_transcribed FROM audio_files LIMIT 1")
    except sqlite3.OperationalError:
        conn.execute("ALTER TABLE audio_files ADD COLUMN is_transcribed INTEGER DEFAULT 0")
        conn.commit()
    except Exception as e:
        state_info["status"] = "DB Error"
        state_info["details"] = str(e)
        return False
    finally:
        if 'conn' in locals(): conn.close()
    return True

# ================= WORKER =================
async def run_tester():
    if not ensure_db_schema(): return

    # 1. SETUP
    state_info["status"] = "Setup"
    if TEMP_DIR.exists(): shutil.rmtree(TEMP_DIR)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    # 2. DB QUERY
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, audio_path FROM audio_files 
        WHERE (is_transcribed = 0 OR is_transcribed IS NULL) 
        AND has_subtitle = 0 
        LIMIT 1
    """)
    row = cursor.fetchone()
    conn.close()

    if not row:
        state_info["status"] = "Done"
        state_info["details"] = "No files to transcribe."
        return

    # 3. DOWNLOAD
    rel_path = row["audio_path"].replace(STRIP_PREFIX, "")
    local_path = TEMP_DIR / rel_path
    
    state_info["status"] = "Downloading"
    state_info["details"] = f"Fetching {local_path.name}"
    local_path.parent.mkdir(parents=True, exist_ok=True)
    
    proc = await asyncio.create_subprocess_exec(
        "rclone", "copyto", f"{RCLONE_REMOTE}/{rel_path}", str(local_path),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()

    if not local_path.exists():
        state_info["status"] = "Download Error"
        state_info["details"] = stderr.decode()[:100]
        return

    # 4. TRANSCRIBE
    state_info["status"] = "Transcribing"
    state_info["details"] = f"Loading {MODEL_SIZE}..."
    try:
        model = stable_whisper.load_faster_whisper(MODEL_SIZE, device="cuda", compute_type="float16")
        
        state_info["details"] = "Processing on GPU..."
        # NOTE: verbose=False prevents the internal progress bar from breaking our UI
        result = await asyncio.get_event_loop().run_in_executor(
            None, lambda: model.transcribe(
                str(local_path), 
                vad=True, 
                batch_size=BATCH_SIZE,
                regroup="mg=0.2_sp=.* /./. /。/?/? /？/!/! /！/,/, _sl=25",
                verbose=False
            )
        )
    except Exception as e:
        state_info["status"] = "GPU Error"
        state_info["details"] = str(e)
        return

    # 5. SAVE (THE FIX IS HERE)
    state_info["status"] = "Saving"
    srt_name = OUTPUT_PREFIX + local_path.stem + ".srt"
    local_srt = local_path.parent / srt_name
    
    # word_level=False removes the <font> tags and creates clean sentences
    result.to_srt_vtt(str(local_srt), word_level=False)
    
    # 6. ARCHIVE & UPLOAD
    # Local Archive
    dest = ARCHIVE_DIR / rel_path
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(local_srt, dest.parent / srt_name)

    # GDrive Upload
    state_info["status"] = "Uploading"
    state_info["details"] = "Pushing to GDrive..."
    
    # Use copyto to be explicit about the destination filename
    remote_dest_file = f"{RCLONE_REMOTE}/{Path(rel_path).parent}/{srt_name}"
    
    proc_up = await asyncio.create_subprocess_exec(
        "rclone", "copyto", str(local_srt), remote_dest_file,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    await proc_up.communicate()

    # 7. CLEANUP
    conn = sqlite3.connect(DB_PATH)
    conn.execute("UPDATE audio_files SET is_transcribed = 1 WHERE id = ?", (row["id"],))
    conn.commit()
    conn.close()

    if local_path.exists(): os.remove(local_path)
    if local_srt.exists(): os.remove(local_srt)
    
    state_info["status"] = "Success"
    state_info["details"] = f"Saved: {srt_name}"

# ================= UI LOOP =================
async def ui_loop():
    layout = Layout()
    with Live(layout, refresh_per_second=4, screen=True) as live:
        while state_info["status"] not in ["Success", "Error", "Done", "GPU Error", "DB Error", "Download Error"]:
            
            # Color Logic
            s = state_info["status"]
            color = "blue"
            if s == "Transcribing": color = "yellow"
            if s == "Uploading": color = "magenta"
            
            layout.update(Panel(
                f"\n[bold]Action:[/bold] [{color}]{s}[/{color}]\n"
                f"[bold]Details:[/bold] {state_info['details']}",
                title="Tester V7 (Clean SRT Fix)",
                border_style=color
            ))
            await asyncio.sleep(0.5)
            
        # Final Screen
        final_color = "green" if state_info["status"] == "Success" else "red"
        layout.update(Panel(
            f"\n[bold]Final Status:[/bold] [{final_color}]{state_info['status']}[/{final_color}]\n"
            f"[bold]Result:[/bold] {state_info['details']}",
            title="Execution Finished",
            border_style=final_color
        ))
        await asyncio.sleep(3)

async def main():
    await asyncio.gather(run_tester(), ui_loop())

if __name__ == "__main__":
    asyncio.run(main())
import os
import shutil
import subprocess
from pathlib import Path
import stable_whisper

# ================= CONFIGURATION =================
# 1. Local Scan Root
LOCAL_ROOT = Path("/workspace/RunpodAsmr").resolve()

# 2. Rclone Destination Root
# Files will go to: gdrive:RunpodAsmr/Audio/RJxxx/file.srt
REMOTE_ROOT = "gdrive:RunpodAsmr/Audio"

# 3. Processing Config
RAM_DIR = Path("/dev/shm/cleanup_buffer").resolve()
MODEL_SIZE = "large-v3-turbo"
COMPUTE_TYPE = "float16"
AUDIO_EXTS = {'.opus', '.mp3', '.wav', '.m4a', '.flac', '.mp4'}
# =================================================

def run_cleanup_job():
    print(f"--- STARTING FINAL CLEANUP ---")
    print(f"Scanning: {LOCAL_ROOT}")
    
    # 1. Identify Leftover Files
    todo = []
    for root, dirs, files in os.walk(LOCAL_ROOT):
        for name in files:
            file_path = Path(root) / name
            if file_path.suffix.lower() in AUDIO_EXTS:
                # Check if SRT already exists
                srt_path = file_path.with_suffix(".srt")
                if not srt_path.exists():
                    todo.append(file_path)

    if not todo:
        print("🎉 No untranscribed files found. You are done!")
        return

    print(f"Found {len(todo)} leftover files.")
    
    # 2. Load Model
    print("Loading Model...")
    RAM_DIR.mkdir(parents=True, exist_ok=True)
    try:
        model = stable_whisper.load_faster_whisper(MODEL_SIZE, device="cuda", compute_type=COMPUTE_TYPE)
    except Exception as e:
        print(f"[CRITICAL] Model load failed: {e}")
        return

    # 3. Process Loop
    for i, audio_path in enumerate(todo):
        wav_path = RAM_DIR / f"temp_{i}.wav"
        try:
            print(f"\n[{i+1}/{len(todo)}] Processing: {audio_path.relative_to(LOCAL_ROOT)}")
            
            # A. Convert to WAV in RAM (Matches worker.py robustness)
            # Using quotes handles spaces/Japanese characters safely
            cmd = f'ffmpeg -y -i "{audio_path}" -ar 16000 -ac 1 -c:a pcm_s16le "{wav_path}" -hide_banner -loglevel error'
            os.system(cmd)
            
            if not wav_path.exists():
                print(f"   ❌ [ERROR] FFmpeg failed to read audio.")
                continue

            # B. Transcribe
            result = model.transcribe(
                str(wav_path),
                batch_size=48,
                vad=True,
                verbose=None,
                regroup="mg=0.2_sp=.* /./. /。/?/? /？/!/! /！/,/, _sl=25"
            )
            
            # C. Save SRT Locally
            srt_path = audio_path.with_suffix(".srt")
            result.to_srt_vtt(str(srt_path), word_level=False)
            print("   ✅ Transcribed.")
            
            # D. Rclone Upload (Move SRT to GDrive)
            # Logic: preserve relative folder structure
            # If local is RJ123/file.srt -> Remote is gdrive:RunpodAsmr/Audio/RJ123/
            rel_dir = audio_path.parent.relative_to(LOCAL_ROOT)
            remote_dest = f"{REMOTE_ROOT}/{rel_dir}"
            
            # Run rclone move (This deletes the local .srt after upload)
            rclone_cmd = [
                "rclone", "move", str(srt_path), remote_dest,
                "--transfers", "10",
                "--no-check-certificate" 
            ]
            
            proc = subprocess.run(rclone_cmd, capture_output=True, text=True)
            
            if proc.returncode == 0:
                print(f"   ☁️  Uploaded SRT to: {remote_dest}")
                
                # E. DELETE LOCAL AUDIO (Cleanup)
                os.remove(audio_path)
                print(f"   🗑️  Deleted local audio file.")
            else:
                print(f"   ⚠️ [UPLOAD FAIL] Keeping audio file. Error: {proc.stderr}")

        except Exception as e:
            print(f"   ❌ Exception: {e}")
        finally:
            # Clean up RAM buffer
            if wav_path.exists():
                os.remove(wav_path)

    # Cleanup RAM Folder
    if RAM_DIR.exists():
        shutil.rmtree(RAM_DIR)
    print("\n--- JOB COMPLETE ---")

if __name__ == "__main__":
    run_cleanup_job()